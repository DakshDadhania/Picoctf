"""Related to configuration."""

__all__ = ['config']
